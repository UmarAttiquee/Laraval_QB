<?php

namespace App\Http\Controllers;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;


class PersonController extends Controller
{
    public function personall()
    {

        $user = DB::table('person')->get();
        return view('person_fl.personall', ['data' => $user]);
    }



    public function personone($id)
    {

        $user = DB::table('person')->find($id);
        return view('person_fl.personone', ['data' => $user]);
    }

    public function person_del($id)
    {
      DB::table('person')->where('id' , $id)->delete();


            return redirect('person');

    }

    public function person_add_page()
    {
        return view('person_fl.personadd');
    }
    public function person_add(Request $request)
    {
        $user = DB::table('person')->insert([
           'city' => $request->city,
           'country' => $request->country,
        ]);
        if($user)
        {
        return redirect('person');
        }
        else
        {
            return "Record NOt added";
        }
    }


public function person_update_page(string $id)
{
     $user = DB::table('person')->find($id);
    return view('person_fl.personupdate' , ['data' => $user]);
}

public function person_update(string $id , Request $request)
{
    DB::beginTransaction();
    try
    {
        $user = DB::table('person')->where('id' , $id)->update([
            'city' => $request->city,
            'country' => $request->country,
         ]);
         if($user)
         {
         DB::commit();
         return redirect('person');
         }

    }
    catch(Exception $e)
    {
     DB::rollBack();
    }

}
}
