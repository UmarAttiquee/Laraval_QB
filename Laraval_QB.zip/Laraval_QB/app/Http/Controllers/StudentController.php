<?php

namespace App\Http\Controllers;

use App\Models\student;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class StudentController extends Controller
{


    public function all_students()
    {
        $stu = DB::table('student')->get();
        return $stu;
    }

    public function union_all()
    {
        $test = true;
        $student = DB::table('student')->select('city', 'country')->where('city', '=','Lakhnao');
        // $student = DB::table('student')->select('city' , 'country' , 'city');
        // ->join('person' , 'student.city' , '=' , 'person.id');
        $person = DB::table('person')->select('city',  'country')
        ->when($test , function($q)
        {
            $q->where('city', '=','Islamabad');
        } ,function($q)
        {
            $q->where('city', '=','Multan');

        })
        ->union($student)
        ->get();

        // $student = DB::table('student')->select('city' , 'country' , 'city');
        // ->join('person' , 'Replace.city' , '=' , 'person.id');
        return $person;
    }


    public function chunk()
    {
        DB::table('person')->orderBy('id')->chunk(2, function($per)
        {

            foreach($per as $person)
            {
                echo $person->city;
                 echo '<br>';
            }
        });
    }

}
