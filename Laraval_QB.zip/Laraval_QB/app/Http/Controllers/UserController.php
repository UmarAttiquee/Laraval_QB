<?php

namespace App\Http\Controllers;

use App\Http\Requests\studentRequest;
use App\Models\User;
use App\Rules\Uppercase;
use Exception;
use Illuminate\Database\Query\JoinClause;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;





class UserController extends Controller
{



    public function showall()


    {
        $user = DB::table('users')->orderBy('id')->paginate(36);

        return view('showall_page', ['data' => $user]);
    }


    public function add_users(studentRequest $request)
    {
        // $req = $request->validate([
        //     'name' => ['required'],
        //     'email' => ['required', 'unique:users', 'email'],
        //     'password' => ['required' , 'confirmed'],
        //     'city' => ['required'],
        //     'age' => ['required', 'numeric' ,'between:18,22' ],
        // ]);

        if (is_null($request)) {
            return "Invalid Input";
        } else {
            try {
                DB::beginTransaction();

                $userInserted = DB::table('users')->insert([
                    'name' => $request->name,
                    'email' => $request->email,

                    'password' => Hash::make($request->password),
                    'city' => $request->city,
                    'age' => $request->age,

                ]);

                if ($userInserted) {
                    DB::commit();
                    return  redirect('showall');
                } else {
                    DB::rollBack();
                    return "User Not added";
                }
            } catch (Exception $e) {
                DB::rollBack();
            }

            return "Logical Error: " . $e->getMessage();
        }
        // return $req->all();
    }


    public function showwall_byid($id)
    {
        $user = DB::table('users')->where('id', $id)->first();
        return view('showone_page', ['data' => $user]);
    }

    public function del($id)
    {
        $user = DB::table('users')->where('id', $id)->delete();
        return redirect('showall');
    }


    public function upd_page($id)
    {
        $user =  DB::table('users')->find($id);
        return  view('update_page', ['data' => $user]);
    }

    public function update_user(Request $request, string $id)
    {
        DB::beginTransaction();

        $user = DB::table('users')->where('id', $id)->update([
            'name' => $request->name,
            'email' => $request->email,
            'password' => $request->password,

            'city' => $request->city,
            'age' => $request->age,


        ]);
        DB::commit();
        if ($user) {
            return redirect('showall');
        } else {
            return "Not Updated";
        }
    }






    public function joinTable()
    {
        // $user = DB::table('users')
        // ->rightJoin('person', 'users.city', '=', 'person.id')
        // // ->select('users.*', 'person.city', 'person.country')

        // // ->where('person.city', '=', 'Karachi')


        // ->get();

        // return view('joinTables', ['data' => $user]);



        $user = DB::table('users')->leftJoin('person', function (JoinClause $j) {
            $j->on('users.city', '=', 'person.id');
        })->get();
        return $user;
    }


    // public function joinTable()
    // {
    //     $user = DB::table('users')
    //         ->join('person', 'users.city', '=', 'person.id')
    //         ->select(DB::raw('count(*) as Record_Counts'), 'person.city') // Select the count of records and the 'city' column
    //         ->groupBy('city')
    //         ->orderBy('Record_Counts') // Order by the count of records in descending order
    //         // ->having('person.city' ,'=', 'Karachi')
    //        ->havingBetween('Record_Counts' , [3,4])
    //         ->get();

    //     return $user;
    // }



    public function signup_page()
    {
        return view('signin');
    }

    public function login_page()
    {
        return view('login');
    }


    public function login(Request $request)
    {
        $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required', 'min:8'],
        ]);

        $user = User::where('email', $request->email)->first();

        if ($user && Hash::check($request->password, $user->password)) {
            $request->session()->put('loginId' , $user->id);
            return redirect('dash'); // Assuming 'showall' is the name of the route
        } else {
            return "User Not Logged In";
        }
    }





    public function signup(Request $request)
    {
        $request->validate([
            'name' => ['required', 'string'], // Name is required and must be a string
            'email' => ['required', 'email', 'unique:users'], // Email is required, must be in email format, and must be unique in the 'users' table
            'password' => ['required', 'min:1'], // Password is required, must be a string, at least 8 characters long, and confirmed with a 'password_confirmation' field
            'city' => ['required'],
            'age' => ['required'],
        ]);

        $user = new User;
        $user->name = $request->name;
        $user->email = $request->email;

        $user->password = Hash::make($request->password);
        $user->city = $request->city;
        $user->age = $request->age;
        $res = $user->save();
        if ($res) {
            return back()->with('success', 'User Registered Successfully');
        } else {
            return back()->with('fail', 'User Not created');
        }
    }






    public function dash()
    {
        $data = array();
        if(Session::has('loginId'))
        {
            $data = User::where('id', '=' , Session::get('loginId'))->first();

        }
        return view('dash' ,compact('data'));
    }

    public function logout(Request $request)
    {
        Auth::logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect('login_page');
    }
}
