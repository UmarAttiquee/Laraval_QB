{{-- @if ($errors->any())
    <ul>
        @foreach ($errors->all() as $error)
            <li>{{ $error }}</li>
        @endforeach


    </ul>
@endif --}}
<form method="POST" action="{{ route('add_user') }}">
    @csrf
    <div class="form-group">
        <label for="name">Name:</label>
        <input value="{{old('name')}}" type="text" class="form-control" id="name" name="name">
        <span>
            @error('name')
             {{$message}}
            @enderror
        </span>
    </div>
    <div class="form-group">
        <label for="email">Email:</label>
        <input value="{{old('email')}}" type="email" class="form-control" id="email" name="email">
        <span>
            @error('email')
             {{$message}}
            @enderror
        </span>
    </div>
    <div class="form-group">
        <label for="password">Password:</label>
        <input value="{{old('password')}}" type="password" class="form-control" id="password" name="password">
        <span>
            @error('password')
             {{$message}}
            @enderror
        </span>
    </div>

    <div class="form-group">
        <label for="password_confirmation">Password Confirmation:</label>
        <input value="{{old('password_confirmation')}}" type="password" class="form-control" id="password_confirmation" name="password_confirmation">
        <span>
            @error('password_confirmation')
             {{$message}}
            @enderror
        </span>
    </div>




    <div class="form-group">
        <label for="name">city:</label>
        <input value="{{old('city')}}" type="text" class="form-control" id="city" name="city">
    </div>

    <div class="form-group">
        <label for="name">age:</label>
        <input value="{{old('age')}}" type="number" class="form-control" id="age" name="age">
        <span>
            @error('age')
             {{$message}}
            @enderror
        </span>
    </div>


    <button type="submit" class="btn btn-primary">Submit</button>
</form>
