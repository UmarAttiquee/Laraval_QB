
{{$data->name}} <br>
{{$data->email}}

<a href="{{ route('logout') }}">Logout</a>

