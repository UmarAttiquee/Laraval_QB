@extends('Master');

<table class="table table-striped">
    <thead class="thead-dark">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Password</th>

            <th>City</th>
            <th>Age</th>
            <th>Country</th>
            <th>View</th>
            <th>Delete</th>
            <th>Update</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($data as $key => $value)
        <tr>
            <td>{{ $value->id }}</td>
            <td>{{ $value->name }}</td>
            <td>{{ $value->email }}</td>
            <td>{{ $value->password }}</td>
            <td>{{ $value->city }}</td>
            <td>{{ $value->age }}</td>
            <td>{{ $value->country }}</td>
            <td><a href="{{ route('showone_page', $value->id) }}" class="btn btn-info btn-sm">View</a></td>
            <td><a href="{{ route('del', $value->id) }}" class="btn btn-danger btn-sm">Delete</a></td>
            <td><a href="{{ route('upd_page', $value->id) }}" class="btn btn-warning btn-sm">Update</a></td>
        </tr>
        @endforeach
    </tbody>
</table>

{{-- {{ $data->links('pagination::bootstrap-5') }} --}}
