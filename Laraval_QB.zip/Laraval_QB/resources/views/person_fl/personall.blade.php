

<h1 class="h1">SHOW ALL PERSONS</h1>
@extends('Master');
<a href="{{ route('person_add_page') }}" class="btn btn-primary mb-3">Add New Record</a>

<table class="table table-striped">
    <thead class="thead-dark">
        <tr>
            <th>Id</th>
            <th>City</th>
            <th>Country</th>
            <th>View</th>
            <th>Delete</th>
            <th>Update</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($data as $key => $value)
        <tr>
            <td>{{ $value->id }}</td>
            <td>{{ $value->city }}</td>
            <td>{{ $value->country }}</td>
            <td><a href="{{ route('personone', $value->id) }}" class="btn btn-info btn-sm">View</a></td>
            <td><a href="{{ route('person_del', $value->id) }}" class="btn btn-danger btn-sm">Delete</a></td>
            <td><a href="{{ route('person_update_page', $value->id) }}" class="btn btn-warning btn-sm">Update</a></td>
        </tr>
        @endforeach
    </tbody>
</table>
