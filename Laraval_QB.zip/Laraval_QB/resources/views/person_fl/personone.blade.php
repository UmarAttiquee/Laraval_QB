<h1>Single Record</h1>
{{$data->id}}
{{$data->city}}
{{$data->country}}


<a href="{{route('person')}}">BACK</a>
