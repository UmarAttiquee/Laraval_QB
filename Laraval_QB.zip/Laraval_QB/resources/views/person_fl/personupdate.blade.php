
<h1>Update Record</h1>

<form method="POST" action="{{ route('person_update' , ['id' => $data->id ]) }}">
  @csrf
  <div class="form-group">
    <label for="city">City:</label>
    <input value="{{$data->city}}" type="text" class="form-control" id="city" name="city">
  </div>
  <div class="form-group">
    <label for="country">Country:</label>
    <input value="{{$data->country}}" type="text" class="form-control" id="country" name="country">
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
