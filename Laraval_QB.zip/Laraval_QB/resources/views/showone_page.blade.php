@extends('Master');

<h1>User Details</h1>



<table class="table">
    <tr>
        <th>Name</th>
        <td>{{ $data->name }}</td>
    </tr>
    <tr>
        <th>Email</th>
        <td>{{ $data->email }}</td>
    </tr>

    <tr>
        <th>Password</th>
        <td>{{ $data->password }}</td>
    </tr>




    <tr>
        <th>City</th>
        <td>{{ $data->city }}</td>
    </tr>

    <tr>
        <th>City</th>
        <td>{{ $data->age }}</td>
    </tr>
    <!-- Don't display the password for security reasons -->
</table>


<a href="{{route('showall')}}">Back To Home Page</a>
