@extends('Master');

<form method="POST" action="{{ route('signup') }}">
    @if (Session::has('success'))
        <div class="alert alert-success">{{ Session::get('success') }}</div>
    @elseif(Session::has('fail'))
        <div class="alert alert-danger">{{ Session::get('fail') }}</div>
    @endif

    @csrf
    <div class="form-group">
        <label for="name">Enter Your Name</label>
        <input type="text" class="form-control" id="name" name="name">
        <span class="text-danger">
            @error('name')
                {{ $message }}
            @enderror
        </span>
    </div>
    <div class="form-group">
        <label for="email">Enter Your Email</label>
        <input type="email" class="form-control" id="email" name="email">
        <span class="text-danger">
            @error('email')
                {{ $message }}
            @enderror
        </span>
    </div>
    <div class="form-group">
        <label for="password">Enter Your Password</label>
        <input type="password" class="form-control" id="password" name="password">
        <span class="text-danger">
            @error('password')
                {{ $message }}
            @enderror
        </span>
    </div>

    <div class="form-group">
        <label for="city">Enter Your city</label>
        <input type="text" class="form-control" id="city" name="city">
        <span class="text-danger">
            @error('city')
                {{ $message }}
            @enderror
        </span>
    </div>



    <div class="form-group">
        <label for="age">Enter Your age</label>
        <input type="number" class="form-control" id="age" name="age">
        <span class="text-danger">
            @error('age')
                {{ $message }}
            @enderror
        </span>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>
