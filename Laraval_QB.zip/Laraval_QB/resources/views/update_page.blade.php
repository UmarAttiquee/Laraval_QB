<form method="POST" action="{{route('update_user' , ['id' => $data->id] )}}">
    @csrf
    <div class="form-group">
      <label for="name">Name:</label>
      <input value="{{$data->name}}" type="text" class="form-control" id="name" name="name">
    </div>
    <div class="form-group">
      <label for="email">Email:</label>
      <input value="{{$data->email}}" type="email" class="form-control" id="email" name="email">
    </div>
    <div class="form-group">
      <label for="password">Password:</label>
      <input value="{{$data->password}}" type="password" class="form-control" id="password" name="password">
    </div>







      <div class="form-group">
        <label for="name">City:</label>
        <input value="{{$data->city}}" type="text" class="form-control" id="city" name="city">
      </div>

      <div class="form-group">
        <label for="name">age:</label>
        <input value="{{$data->age}}" type="text" class="form-control" id="age" name="age">
      </div>

    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
