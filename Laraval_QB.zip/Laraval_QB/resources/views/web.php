<?php

use App\Http\Controllers\PersonController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;


Route::get('/welcome', function () {
    return view('welcome');
});


Route::post('/add_user' , [UserController::class , 'add_users' ])->name('add_user');
Route::view('/add' , 'add_page')->name('add');

Route::get('/showall' , [UserController::class, 'showall'])->name('showall');
Route::get('/showall/{id}' ,[UserController::class , 'showwall_byid' ])->name('showone_page');


Route::get('/del/{id}' , [UserController::class , 'del'])->name('del');


Route::post('/update_user/{id}' , [UserController::class , 'update_user'])->name('update_user');
Route::get('/upd_page/{id}' , [UserController::class , 'upd_page'])->name('upd_page');


Route::fallback(function () {
    return "Page Not Found";
});





Route::get('/person' , [PersonController::class, 'personall'])->name('person');
Route::get('/personone/{id}' , [PersonController::class, 'personone'])->name('personone');

Route::get('/person_del/{id}' , [PersonController::class, 'person_del'])->name('person_del');



Route::post('/person_add' , [PersonController::class , 'person_add'] )->name('person_add');
Route::get('/perosn_add_page' , [PersonController::class, 'person_add_page'])->name('person_add_page');



Route::post('/person_update/{id}' , [PersonController::class , 'person_update'])->name('person_update');
Route::get('/person_update_page/{id}' , [PersonController::class , 'person_update_page'])->name('person_update_page');



// JOINS TABLES


Route::get('/' , [UserController::class , 'joinTable'])->name('join');


Route::get('/stu' , [StudentController::class , 'all_students'])->name('stu');
Route::get('/union' , [StudentController::class , 'union_all']) ->name('union');
Route::get('/chunk' , [StudentController::class , 'chunk']) ->name('chunk');



// Login and Sign up

// Route::get('/signup_page', [UserController::class, 'signup_page'])->name('signup_page');
// Route::post('/signup', [UserController::class, 'signup'])->name('signup');

Route::post('/signup', [UserController::class, 'signup'])->name('signup');
Route::get('/signup_page', [UserController::class, 'signup_page'])->name('signup_page');

Route::get('/login_page', [UserController::class, 'login_page'])->name('login_page');
Route::post('/loginu', [UserController::class, 'login'])->name('loginu');


Route::get('/dash', [UserController::class, 'dash'])->name('dash');

Route::get('/logout', [UserController::class, 'logout'])->name('logout');
